const express = require('express');

const {
    QueryAsync
} = require('../../Infrastructure/PostgreSQL')
const UsersManager = require('../../WebCore/Managers/UsersManager.js');
const { authorizeAndExtractTokenAsync } = require('../Filters/JWTFilter.js');
const bodyParser = require('body-parser');
const jsonParser = bodyParser.json();
const ServerError = require('../Models/ServerError.js');
const sendEmail = require('../EmailAuth');
const {
    UserLoginBody,
    UserRegisterBody,
    UserScoreResponse,
    UserRegisterResponse,
    UserLoginResponse,
} = require ('../Models/Users.js');

const ResponseFilter = require('../Filters/ResponseFilter.js');
const AuthorizationFilter = require('../Filters/AuthorizationFilter.js');
const RoleConstants = require('../Constants/Roles.js');

const Router = express.Router();

Router.post('/register', jsonParser, async (req, res) => {
    const userRegisterBody = new UserRegisterBody(req.body);
    console.log('reg body:', userRegisterBody);

    const user = await UsersManager.registerAsync(userRegisterBody.Username, userRegisterBody.Mail, userRegisterBody.Password);
    const reg_user = new UserRegisterResponse(user);

    ResponseFilter.setResponseDetails(res, 201, reg_user);
});

Router.post('/login', jsonParser, async (req, res) => {

    const userLoginBody = new UserLoginBody(req.body);
    console.log('log body:', userLoginBody);

    const userDto = await UsersManager.authenticateAsync(userLoginBody.Username, userLoginBody.Password);
    const user = new UserLoginResponse(userDto.Token, userDto.Role);

    ResponseFilter.setResponseDetails(res, 200, user);
});

Router.get('/', authorizeAndExtractTokenAsync, AuthorizationFilter.authorizeRoles(RoleConstants.ADMIN), async (req, res) => {

    const users = await QueryAsync('SELECT id, username, role_id FROM users');

    ResponseFilter.setResponseDetails(res, 200, users.map(user => new UserRegisterResponse(user)));
});


Router.get('/best', jsonParser, async (req, res) => {

    const users = await QueryAsync('SELECT username, score \
                            FROM users \
                            ORDER BY score DESC, id \
                            LIMIT 10');
    ResponseFilter.setResponseDetails(res, 200, users.map(user => new UserScoreResponse(user)));
});


Router.get('/:userId/role/:roleId', jsonParser, authorizeAndExtractTokenAsync, AuthorizationFilter.authorizeRoles(RoleConstants.ADMIN), async (req, res) => {
    let {
        userId,
        roleId
    } = req.params;

    userId = parseInt(userId);
    roleId = parseInt(roleId);

    const users = await QueryAsync(`SELECT u.id, u.password, u.mail_confirmed,
                                u.username, r.value as role,
                                r.id as role_id FROM users u 
                                JOIN roles r ON r.id = u.role_id
                                WHERE u.id = ${userId}`);
    const user = users[0];
    if (!user) {
        ResponseFilter.setResponseDetails(res, 404, `Nu exista utilizatorul cu id-ul ${userId}`);
    }

    const updatedUser = await (async (user_id, role_id) => {
        console.info(`Updating role_id ${role_id} for id=${user_id} from database async...`);

        const users = await QueryAsync(`UPDATE users SET role_id = ${role_id} WHERE id = ${user_id} RETURNING *`);
        return users[0];
    })(userId, roleId);

    ResponseFilter.setResponseDetails(res, 201, updatedUser);
});

module.exports = Router;
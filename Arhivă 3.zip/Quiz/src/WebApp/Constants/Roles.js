module.exports = {
    ADMIN: 'ADMIN',
    USER: 'USER',
    MANAGER: 'MANAGER'
};
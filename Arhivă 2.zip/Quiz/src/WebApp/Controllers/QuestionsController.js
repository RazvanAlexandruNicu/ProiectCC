const express = require('express');
const MessageQueue = require('../../Infrastructure/RabbitMQ');
const {
    QueryAsync
} = require('../../Infrastructure/PostgreSQL')

const QUEUE = 'quiz';

const ServerError = require('../Models/ServerError.js');
const { QuestionPostBody, QuestionPutBody, QuestionResponse, QuestionManagerResponse, QuestionAnswerBody, QuestionAnswerResponseBody } = require('../Models/Question.js');
const { authorizeAndExtractTokenAsync } = require('../Filters/JWTFilter.js');
const { setResponseDetails } = require('../Filters/ResponseFilter.js');
const AuthorizationFilter = require('../Filters/AuthorizationFilter.js');
const RoleConstants = require('../Constants/Roles.js');

const bodyParser = require('body-parser');
const jsonParser = bodyParser.json();

const Router = express.Router();

Router.post('/', jsonParser, authorizeAndExtractTokenAsync, AuthorizationFilter.authorizeRoles(RoleConstants.MANAGER), async (req, res) => {

    const {
        full_statement,
        a0,
        a1,
        a2,
        a3,
        domain,
        correct
    } = req.body
    let question
    if ('domain' in req.body) {
        try {
            await MessageQueue.PublishMessageAsync(QUEUE, {
                "op_name": "add_question_with_domain",
                "op": {
                    full_statement,
                    a0,
                    a1,
                    a2,
                    a3,
                    domain,
                    correct
                }
            });
            res.status(201).end()
        } catch (err) {
            console.error(err);
            res.status(500).send("Something bad happened");
        }
    } else {
        try {
            await MessageQueue.PublishMessageAsync(QUEUE, {
                "op_name": "add_question_without_domain",
                "op": {
                    full_statement,
                    a0,
                    a1,
                    a2,
                    a3,
                    correct
                }
            });
            res.status(201).end()
        } catch (err) {
            console.error(err);
            res.status(500).send("Something bad happened");
        }
    }
    setResponseDetails(res, 201, new QuestionManagerResponse(question), req.originalUrl);
});


Router.get('/all', authorizeAndExtractTokenAsync, AuthorizationFilter.authorizeRoles(RoleConstants.MANAGER), async (req, res) => {

    const questions = await QueryAsync('SELECT Q.id as "question_id", Q.full_statement as "question_statement", Q.a0 as "right_first_answer", Q.a1 as "second_answer", \
                                    Q.a2 as "third_answer", Q.a3 as "fourth_answer", Q.domain as "question_domain", Q.correct as "correct" \
                            FROM questions Q');
    setResponseDetails(res, 200, questions.map(question => new QuestionManagerResponse({"id": question.question_id,
                        "full_statement": question.question_statement,
                        "a0": question.right_first_answer,
                        "a1": question.second_answer,
                        "a2": question.third_answer,
                        "a3": question.fourth_answer,
                        "domain": question.question_domain,
                        "correct": question.correct})));
});

Router.get('/:id', authorizeAndExtractTokenAsync, AuthorizationFilter.authorizeRoles(RoleConstants.MANAGER), async (req, res) => {
    let {
        id
    } = req.params;

    id = parseInt(id);

    if (!id || id < 1) {
        setResponseDetails(res, 400, "Id should be a positive integer");
    }

    const q = await QueryAsync(`SELECT Q.id as "question_id", Q.full_statement as "question_statement", Q.a0 as "right_first_answer", Q.a1 as "second_answer", \
                                    Q.a2 as "third_answer", Q.a3 as "fourth_answer", Q.domain as "question_domain", Q.correct as "correct" \
                            FROM questions Q \
                            WHERE Q.id = ${id}`);

    if (q.length === 0) {
        setResponseDetails(res, 404, `Question with id ${id} does not exist!`);
    }
    let question = q[0]

    setResponseDetails(res, 200, new QuestionManagerResponse({"id": question.question_id,
        "full_statement": question.question_statement,
        "a0": question.right_first_answer,
        "a1": question.second_answer,
        "a2": question.third_answer,
        "a3": question.fourth_answer,
        "domain": question.question_domain,
        "correct": question.correct}));
});

Router.get('/get/random', authorizeAndExtractTokenAsync, async (req, res) => {

    const no_samples = 5

    const questions = await QueryAsync(`SELECT Q.id as "question_id", Q.full_statement as "question_statement", Q.a0 as "right_first_answer", Q.a1 as "second_answer", \
                                    Q.a2 as "third_answer", Q.a3 as "fourth_answer", Q.domain as "question_domain" \
                            FROM questions Q \
                            ORDER BY RANDOM() \
                            LIMIT ${no_samples}`);
    setResponseDetails(res, 200, questions.map(question => new QuestionResponse({"id": question.question_id,
        "full_statement": question.question_statement,
        "a0": question.right_first_answer,
        "a1": question.second_answer,
        "a2": question.third_answer,
        "a3": question.fourth_answer,
        "domain": question.question_domain})));
});

Router.get('/get/random/:domainName', authorizeAndExtractTokenAsync, async (req, res) => {

    const no_samples = 5
    let {
        domainName
    } = req.params;

    const questions = await QueryAsync(`SELECT Q.id as "question_id", Q.full_statement as "question_statement", Q.a0 as "right_first_answer", Q.a1 as "second_answer", \
                                    Q.a2 as "third_answer", Q.a3 as "fourth_answer" \
                            FROM questions Q WHERE Q.domain=(${domainName})\
                            ORDER BY RANDOM() \
                            LIMIT ${no_samples}`);

    setResponseDetails(res, 200, questions.map(question => new QuestionResponse({"id": question.question_id,
                        "full_statement": question.question_statement,
                        "a0": question.right_first_answer,
                        "a1": question.second_answer,
                        "a2": question.third_answer,
                        "a3": question.fourth_answer,
                        "domain": domainName})));
});


Router.put('/:id', jsonParser, authorizeAndExtractTokenAsync, AuthorizationFilter.authorizeRoles(RoleConstants.MANAGER), async (req, res) => {

    const questionBody = new QuestionPutBody(req.body, req.params.id);

    try {
        await MessageQueue.PublishMessageAsync(QUEUE, {
            "op_name": "update_question",
            "op": {
                id: req.params.id,
                full_statement : questionBody.Statement,
                a0 : questionBody.FirstAnswer,
                a1 : questionBody.SecondAnswer,
                a2 : questionBody.ThirdAnswer,
                a3 : questionBody.FourthAnswer,
                domain : questionBody.Domain,
                correct : questionBody.Correct
            }
        });
        res.status(201).end()
    } catch (err) {
        console.error(err);
        res.status(500).send("Something bad happened");
    }
});


Router.delete('/:id', authorizeAndExtractTokenAsync, AuthorizationFilter.authorizeRoles(RoleConstants.MANAGER), async (req, res) => {
    const { id } = req.params;

    if (!id || id < 1) {
        setResponseDetails(res, 404, "Id should be a positive integer");
    }

    const questions = await QueryAsync('DELETE FROM questions WHERE id = $1 RETURNING *', [id]);
    const question = questions[0];
    if (!question) {
        setResponseDetails(res, 404, `Question with id ${id} does not exist!`);
    }

    setResponseDetails(res, 204, "Entity deleted succesfully");
});

Router.post('/answer', jsonParser, authorizeAndExtractTokenAsync, async (req, res) => {

    const questionsBody = new QuestionAnswerBody(req.body.answers);

    const {score, pairs} = await (async (answers) => {
        console.info(`Checking answers from database async...`);
        let score = 0;
        let pairs = [];

        for (let index = 0; index < answers.length; index++) {
            const element = answers[index];
            let q = await QueryAsync(`SELECT Q.a0 as "a0", Q.a1 as "a1", Q.a2 as "a2", Q.a3 as "a3", Q.correct as "correct" \
                                FROM questions Q \
                                WHERE Q.id = ${element.question_id}`);
            q = q[0];
            if (q.correct == element.answer) {
                score += 1;
            }
            let possible_answers = [q.a0, q.a1, q.a2, q.a3];
            pairs.push({chosen: possible_answers[parseInt(element.answer.slice(-1))], real: possible_answers[parseInt(q.correct.slice(-1))]});
        }
        console.log(pairs);
        return {score: score, pairs: pairs};
    })(questionsBody.Answers);

    console.log("DONE CHECKING ANSWERS")

    const users = await QueryAsync(`UPDATE users SET score = score + ${score} WHERE id = ${user_id} RETURNING *`)
    const total_score = users[0].score
    setResponseDetails(res, 200, {pairs: pairs, score: score, total_score: total_score}, req.originalUrl);
});


module.exports = Router;
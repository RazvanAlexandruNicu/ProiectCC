const Router = require('express')();

/* Import controllers */
const UsersController = require('./UsersController.js');
const QuestionsController = require('./QuestionsController.js');
const MailController = require('../EmailConfirmationHandler');
const { authorizeAndExtractTokenAsync } = require('../Filters/JWTFilter.js');

/* Add controllers to main router */
Router.use('/users', UsersController);
Router.use('/questions', authorizeAndExtractTokenAsync, QuestionsController);
Router.use('/mail', MailController);

module.exports = Router;
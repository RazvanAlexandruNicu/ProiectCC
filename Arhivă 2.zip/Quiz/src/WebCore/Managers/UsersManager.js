const MessageQueue = require('../../Infrastructure/RabbitMQ');
const AuthenticatedUserDto = require('../DTOs/AuthenticatedUserDto.js');
const RegisteredUserDto = require('../DTOs/RegisteredUserDto.js');
const JwtPayloadDto = require('../DTOs/JwtPayloadDto.js');
const ServerError = require('../../WebApp/Models/ServerError.js');
const {
    QueryAsync
} = require('../../Infrastructure/PostgreSQL')

const { hashPassword, comparePlainTextToHashedPassword } = require('../Security/Password')
const { generateTokenAsync } = require('../Security/Jwt');

const QUEUE = 'quiz';

const authFunction = async (username) => {

    const result = await QueryAsync(`SELECT u.id, u.password, u.mail_confirmed,
                                u.username, r.value as role,
                                r.id as role_id FROM users u 
                                JOIN roles r ON r.id = u.role_id
                                WHERE u.username = $1`, [username]);
    return result
}


const authenticateAsync = async (username, plainTextPassword) => {

    console.info(`Authenticates user with username ${username}`);

    const users = await authFunction(username)
    console.log(users)

    const user= users[0];
    if (!user) {
        throw new ServerError(`Utilizatorul cu username ${username} nu exista in sistem!`, 404);
    }

    //const hashedPassword = hashPassword(plainTextPassword);
    const correct_password = await comparePlainTextToHashedPassword(plainTextPassword, user.password);
    if (!correct_password) {
        throw new ServerError(`Parola este gresita!`, 404);
    }
    const payload = new JwtPayloadDto(user.id, user.role);
    const token = await generateTokenAsync(payload);
    return new AuthenticatedUserDto(token, user.username, user.role);
};

const registerAsync = async (username, mail, plainTextPassword) => {
    const hashedPassword = await hashPassword(plainTextPassword);

    try {
        await MessageQueue.PublishMessageAsync(QUEUE, {
            "op_name": "register",
            "op": {
                username: username,
                main: mail,
                password: hashedPassword
            }
        });
    } catch (err) {
        console.error(err);
    }
    return new RegisteredUserDto(-1, username, 1);
};

module.exports = {
    authenticateAsync,
    registerAsync
}
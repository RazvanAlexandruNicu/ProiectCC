# Proiect Cloud Computing

Membrii echipa:
* Andreea Lupu
* Anca Dobre
* Razvan-Alexandru Nicu

Tema proiectului:
Realizarea unui joc single-player de tip quiz.

Pentru realizarea proiectului am urmarit structura sugerata in documentatia oferita de echipa de Cloud Computing.
Serviciul este format din urmatoarele microservicii:
* quiz-api : microserviciul care expune API-ul principal al serviciului. Aici are loc autorizarea jucatorilor folosind
JWT si autentificarea acestora.
* procesator: microserviciu care realizeaza pooling la o coada MQTT si interactioneaza direct cu baza de date
* baza de date ce contine tabele pentru utilizatori si intrebari
* o coada mqtt prin care sunt trimite mesaje intre quiz-api si procesator
* adminer: un utilitar pentru gestionarea bazei de date intr-un mod privilegiat
const Router = require('express').Router();

const MyController = require('./items/controllers.js');

Router.use('/items', MyController);

module.exports = Router;

require('dotenv').config()

var amqp = require('amqplib/callback_api');

const {
    addQAsync,
    addQNoDomainAsync,
    updateQByIdAsync,
    addUAsync,
} = require('./items/services.js');


const QUEUE = 'quiz';

amqp.connect(process.env.AMQPURL, (error0, connection) => {
    if (error0) {
        throw error0;
    }
    connection.createChannel((error1, channel) => {
        if (error1) {
            throw error1;
        }

        channel.assertQueue(QUEUE, {
            durable: false
        });

        console.log(" [*] Waiting for messages in %s. To exit press CTRL+C", QUEUE);

        channel.consume(QUEUE, async (msg) => {
            console.log(" [x] Received %s", msg.content.toString());

            if (msg !== null) {
                const jsonPayload = JSON.parse(msg.content);
                switch (jsonPayload.op_name) {
                    case "add_question_with_domain": {
                        try {
                            await addQAsync(jsonPayload.op.full_statement, jsonPayload.op.a0, jsonPayload.op.a1,
                                jsonPayload.op.a2, jsonPayload.op.a3, jsonPayload.op.domain, jsonPayload.op.correct);
                        } catch (err) {
                            console.error(err);
                        }
                        break;
                    }

                    case "add_question_without_domain": {
                        try {
                            await addQNoDomainAsync(jsonPayload.op.full_statement, jsonPayload.op.a0, jsonPayload.op.a1,
                                jsonPayload.op.a2, jsonPayload.op.a3, jsonPayload.op.correct);
                        } catch (err) {
                            console.error(err);
                        }
                        break;
                    }

                    case "update_question": {
                        try {
                            await updateQByIdAsync(jsonPayload.op.id, jsonPayload.op.full_statement, jsonPayload.op.a0,
                                jsonPayload.op.a1, jsonPayload.op.a2, jsonPayload.op.a3, jsonPayload.op.domain, jsonPayload.op.correct);
                        } catch (err) {
                            console.error(err);
                        }
                        break;
                    }

                    case "register": {
                        try {
                            await addUAsync(jsonPayload.op.username, jsonPayload.op.mail, jsonPayload.op.password);
                        } catch (err) {
                            console.error(err);
                        }
                        break;
                    }
                }
            }

            channel.ack(msg);
        });
    });
});

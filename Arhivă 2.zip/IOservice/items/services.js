const {
    query
} = require('../data');


const addQAsync = async (full_statement, a0, a1, a2, a3, domain, correct) => {
    console.info(`Adding question in database async...`);

    const questions = await query('INSERT INTO questions (full_statement, a0, a1, a2, a3, domain, correct) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
        [full_statement, a0, a1, a2, a3, domain, correct]);
    return questions[0];
};

const addQNoDomainAsync = async (full_statement, a0, a1, a2, a3, correct) => {
    console.info(`Adding question in database async...`);

    const questions = await query('INSERT INTO questions (full_statement, a0, a1, a2, a3, correct) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *', [full_statement, a0, a1, a2, a3, correct]);
    return questions[0];
};

const updateQByIdAsync = async (id, full_statement, a0, a1, a2, a3, domain, correct) => {
    console.info(`Updating the question with id=${id} from database async...`);

    const questions = await query('UPDATE questions \
                                        SET full_statement = $2, a0 = $3, a1 = $4, a2 = $5, a3 = $6, domain = $7, correct = $8 \
                                        WHERE id = $1 RETURNING *', [id, full_statement, a0, a1, a2, a3, domain, correct]);
    return questions[0];
};


const addUAsync = async (username, mail, password) => {
    console.info(`Adding user ${username} in database async...`);

    const regularUserId = 1;
    const users = await query('INSERT INTO users (username, mail, password, role_id) VALUES ($1, $2, $3, $4) RETURNING id, username, role_id', [username, mail, password, regularUserId]);
    return users[0];
};



module.exports = {
    addQAsync,
    addQNoDomainAsync,
    updateQByIdAsync,
    addUAsync,
}
